IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[States]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 

Begin
	Print'States Table does not exist'
	CREATE TABLE States
	(
	StatesID BIGINT PRIMARY KEY IDENTITY(1,1)
	,StateName VARCHAR(15)

	)
END
ELSE
BEGIN
	PRINT 'States Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[AddressType]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 

Begin
	Print'AddressType Table does not exist'
	CREATE TABLE AddressType
	(
	AddressTypeID BIGINT PRIMARY KEY IDENTITY(1,1)
	,AddressType VARCHAR(20)

	)
END
ELSE
BEGIN
	PRINT 'AddressType Table Exists'
END
IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[Addresses]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'Addresses Not Exists'
	CREATE TABLE Addresses 
	(
		AddressesID BIGINT PRIMARY KEY IDENTITY(1,1)
		,StatesID BIGINT FOREIGN KEY REFERENCES States(StatesID)
		,AddressTypeID BIGINT FOREIGN KEY REFERENCES AddressType(AddressTypeID)
		,Street VARCHAR(30)
		,City VARCHAR(30)
		,Zip VARCHAR(11)

	)
END
ELSE
BEGIN
	PRINT 'Addresses Table Exists'
END
IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[Gifts]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1)  

Begin
	Print'Gifts Table does not exist'
	CREATE TABLE Gifts
	(
	GiftsID INT PRIMARY KEY IDENTITY(1,1)
	,Gift VARCHAR(3)

	)
END
ELSE
BEGIN
	PRINT 'Gifts Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[Producer]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'Producer Table Not Exists'
	CREATE TABLE Producer 
	(
		ProducerID BIGINT PRIMARY KEY IDENTITY(1,1)
		,FirtsName VARCHAR(20)
		,LastName VARCHAR(20)
	)
END
ELSE
BEGIN
	PRINT 'Producer Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[Product]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'Product Table Not Exists'
	CREATE TABLE Product 
	(
		ProductID BIGINT PRIMARY KEY IDENTITY(1,1)
		,ProducerID BIGINT FOREIGN KEY REFERENCES Producer(ProducerID)
		,ProductName VARCHAR(20)
		,Price INT

	)
END
ELSE
BEGIN
	PRINT 'Product Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[Payment]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 

Begin
	Print'Payment Table does not exist'
	CREATE TABLE Payment
	(
	PaymentID BIGINT PRIMARY KEY IDENTITY(1,1)
	,PaymentType VARCHAR(15) 

	)
END
ELSE
BEGIN
	PRINT 'Payment Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[ShoppingCart]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 

Begin
	Print'ShoppingCart Table does not exist'
	CREATE TABLE ShoppingCart
	(
	ShoppingCartID BIGINT PRIMARY KEY IDENTITY(1,1)
	,ProductsID BIGINT FOREIGN KEY REFERENCES Product(ProductID)
	,Discount DECIMAL
	,TotalCost DECIMAL

	)
END
ELSE
BEGIN
	PRINT 'ShoppingCart Table Exists'
END


IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[Producer]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'Producer Table Not Exists'
	CREATE TABLE Producer 
	(
		ProducerID BIGINT PRIMARY KEY IDENTITY(1,1)
		,FirtsName VARCHAR(20)
		,LastName VARCHAR(20)
	)
END
ELSE
BEGIN
	PRINT 'Producer Table Exists'
END


IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[EmployeeType]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'EmployeeType Table Not Exists'
	CREATE TABLE EmployeeType 
	(
		EmployeeTypeID BIGINT PRIMARY KEY IDENTITY(1,1)
		,EmployeeType VARCHAR(20)

	)
END
ELSE
BEGIN
	PRINT 'EmployeeType Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[Employee]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'Employee Table Not Exists'
	CREATE TABLE Employee 
	(
		EmployeeID BIGINT PRIMARY KEY IDENTITY(1,1)
		,EmployeeTypeID BIGINT FOREIGN KEY REFERENCES EmployeeType(EmployeeTypeID)
		,EmployeeFirstName VARCHAR(20)
		,EmployeeLastName VARCHAR(20)
		,Salary INT
		,Email VARCHAR (30)

	)
END
ELSE
BEGIN
	PRINT 'Employee Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[ConsumerType]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'ConsumerType Table Not Exists'
	CREATE TABLE ConsumerType 
	(
		ConsumerTypeID BIGINT PRIMARY KEY IDENTITY(1,1)
		,ConsumerType VARCHAR(20)

	)
END
ELSE
BEGIN
	PRINT 'ConsumerType Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[Consumer]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'Consumer Table Not Exists'
	CREATE TABLE Consumer 
	(
		ConsumerID BIGINT PRIMARY KEY IDENTITY(1,1)
		,ConsumerTypeID BIGINT FOREIGN KEY REFERENCES ConsumerType(ConsumerTypeID)
		,StatesID BIGINT FOREIGN KEY REFERENCES States(StatesID)
		,AddressTypeID BIGINT FOREIGN KEY REFERENCES AddressType(AddressTypeID)
		,AddressesID BIGINT FOREIGN KEY REFERENCES Addresses(AddressesID)
		,ConsumerFirstName VARCHAR(20)
		,ConsumerLastName VARCHAR(20)

	)
END
ELSE
BEGIN
	PRINT 'Consumer Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[Orders]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'Orders Table Not Exists'
	CREATE TABLE Orders 
	(
		OrdersID BIGINT PRIMARY KEY IDENTITY(1,1)
		,ProductID BIGINT FOREIGN KEY REFERENCES Product(ProductID)
		,AddressTypeID BIGINT FOREIGN KEY REFERENCES AddressType(AddressTypeID)
		,GiftsID INT FOREIGN KEY REFERENCES Gifts(GiftsID)
		,ConsumerID BIGINT FOREIGN KEY REFERENCES Consumer(ConsumerID)
		,OrderTime DATETIME

	)
END
ELSE
BEGIN
	PRINT 'Orders Table Exists'
END


IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[Store]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'Store Table Not Exists'
	CREATE TABLE Store 
	(
		StoreID BIGINT PRIMARY KEY IDENTITY(1,1)
		,AddressID BIGINT FOREIGN KEY REFERENCES Addresses(AddressesID)
		,StoreName VARCHAR(25)
		
	)
END
ELSE
BEGIN
	PRINT 'Store Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[DeliveryType]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'DeliveryType Table Not Exists'
	CREATE TABLE DeliveryType 
	(
		DeliveryTypeID BIGINT PRIMARY KEY IDENTITY(1,1)
		,DeliveryType VARCHAR(15)
	)
END
IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[Shipping]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'Shipping Table Not Exists'
	CREATE TABLE Shipping 
	(
		ShippingID BIGINT PRIMARY KEY IDENTITY(1,1)
		,AddressID BIGINT FOREIGN KEY REFERENCES Addresses(AddressesID)
		,OrdersID BIGINT FOREIGN KEY REFERENCES Orders(OrdersID)
		,DeliveryTypeID BIGINT FOREIGN KEY REFERENCES DeliveryType(DeliveryTypeID)
		,DeliveredDate DATETIME
		
	)
END
ELSE
BEGIN
	PRINT 'Shipping Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[Suppliers]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'Suppliers Table Not Exists'
	CREATE TABLE Suppliers 
	(
		SupplierID BIGINT PRIMARY KEY IDENTITY(1,1)
		,ProductID BIGINT FOREIGN KEY REFERENCES Product(ProductID)
		
	)
END
ELSE
BEGIN
	PRINT 'Suppliers Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[Inventory]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'Inventory Table Not Exists'
	CREATE TABLE Inventory 
	(
		InventoryID BIGINT PRIMARY KEY IDENTITY(1,1)
		,ProductID BIGINT FOREIGN KEY REFERENCES Product(ProductID)
		,StoreID BIGINT FOREIGN KEY REFERENCES Store(StoreID)
		,Quantity INT
		
	)
END
ELSE
BEGIN
	PRINT 'Inventory Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[SalesRecord]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'SalesRecord Table Not Exists'
	CREATE TABLE SalesRecord 
	(
		SalesRecordID BIGINT PRIMARY KEY IDENTITY(1,1)
		,ProductID BIGINT FOREIGN KEY REFERENCES Product(ProductID)
		,StoreID BIGINT FOREIGN KEY REFERENCES Store(StoreID)
		,PaymentID BIGINT FOREIGN KEY REFERENCES Payment(PaymentID)
		,ConsumerID BIGINT FOREIGN KEY REFERENCES Consumer(ConsumerID)
		,Quantity INT
		
	)
END
ELSE
BEGIN
	PRINT 'SalesRecord Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[WishList]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'WishList Table Not Exists'
	CREATE TABLE WishList 
	(
		WishListID BIGINT PRIMARY KEY IDENTITY(1,1)
		,ProductID BIGINT FOREIGN KEY REFERENCES Product(ProductID)
		,Quantity INT
		
	)
END
ELSE
BEGIN
	PRINT 'WhishList Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[UserAcount]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'User Acount Table Not Exists'
	CREATE TABLE UserAcount 
	(
		UserAcountID BIGINT PRIMARY KEY IDENTITY(1,1)
		,ShoppingCartID BIGINT FOREIGN KEY REFERENCES ShoppingCart(ShoppingCartID)
		,WishListID BIGINT FOREIGN KEY REFERENCES WishList(WishListID)
		,PaymentID BIGINT FOREIGN KEY REFERENCES Payment(PaymentID)
		,ConsumerID BIGINT FOREIGN KEY REFERENCES Consumer(ConsumerID)
		
	)
END
ELSE
BEGIN
	PRINT 'User Acount Table Exists'
END
IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[Publisher]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'Publisher Table Not Exists'
	CREATE TABLE Publisher 
	(
		PublisherID BIGINT PRIMARY KEY IDENTITY(1,1)
		,CompanyName Varchar(25)
		
	)
END
ELSE
BEGIN
	PRINT 'Publisher Table Exists'
END
IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[Author]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'Author Table Not Exists'
	CREATE TABLE Author 
	(
		AuthorID BIGINT PRIMARY KEY IDENTITY(1,1)
		,FirstName Varchar(20)
		,LastName Varchar(25)
		
	)
END
ELSE
BEGIN
	PRINT 'Author Table Exists'
END
IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[Book]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'Book Table Not Exists'
	CREATE TABLE Book 
	(
		BookID BIGINT PRIMARY KEY IDENTITY(1,1)
		,AuthorID BIGINT FOREIGN KEY REFERENCES Author(AuthorID)
		,PublisherID BIGINT FOREIGN KEY REFERENCES Publisher(PublisherID)
		,ProductID BIGINT FOREIGN KEY REFERENCES Product(ProductID)
		,Title Varchar(30)
		
	)
END
ELSE
BEGIN
	PRINT 'Book Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[Director]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'Director Table Not Exists'
	CREATE TABLE Director 
	(
		DirectorID BIGINT PRIMARY KEY IDENTITY(1,1)
		,FirstName Varchar(20)
		,LastName Varchar(25)
		
	)
END
ELSE
BEGIN
	PRINT 'Director Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[ProductionCompany]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'ProductionCompany Table Not Exists'
	CREATE TABLE ProductionCompany 
	(
		ProductionCompanyID BIGINT PRIMARY KEY IDENTITY(1,1)
		,ProductionCompanyName Varchar(25)
		
	)
END
ELSE
BEGIN
	PRINT 'ProductionCompany Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[Movie]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'Movie Table Not Exists'
	CREATE TABLE Movie 
	(
		MovieID BIGINT PRIMARY KEY IDENTITY(1,1)
		,DirectorID BIGINT FOREIGN KEY REFERENCES Director(DirectorID)
		,ProductionCompanyID BIGINT FOREIGN KEY REFERENCES ProductionCompany(ProductionCompanyID)
		,ProductID BIGINT FOREIGN KEY REFERENCES Product(ProductID)
		,Title Varchar(30)
		
	)
END
ELSE
BEGIN
	PRINT 'Movie Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[ComputerModel]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'Computure Model Table Not Exists'
	CREATE TABLE ComputerModel
	(
		ComputerModelID BIGINT PRIMARY KEY IDENTITY(1,1)
		,ProducerID BIGINT FOREIGN KEY REFERENCES Producer(ProducerID)
		,ProductID BIGINT FOREIGN KEY REFERENCES Product(ProductID)
		,ComputerModel Varchar(30)
		
	)
END
ELSE
BEGIN
	PRINT 'Computer Model Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
				WHERE id=OBJECT_ID(N'[dbo].[PhoneModel]')
				AND	OBJECTPROPERTY(id,N'IsUserTable')=1) 
BEGIN
	PRINT 'Phone Model Table Not Exists'
	CREATE TABLE PhoneModel
	(
		PhoneModelID BIGINT PRIMARY KEY IDENTITY(1,1)
		,ProducerID BIGINT FOREIGN KEY REFERENCES Producer(ProducerID)
		,ProductID BIGINT FOREIGN KEY REFERENCES Product(ProductID)
		,PhoneModel Varchar(30)
		
	)
END
ELSE
BEGIN
	PRINT 'Phone Model Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
                WHERE id = OBJECT_ID(N'[dbo].[CustomerReviews]')
                AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
    PRINT 'Customer Reviews Table Not Exists'
    CREATE TABLE CustomerReviews
    (
        ReviewID BIGINT PRIMARY KEY IDENTITY(1,1)
        ,ProductID BIGINT FOREIGN KEY REFERENCES Product(ProductID)
        ,ConsumerID BIGINT FOREIGN KEY REFERENCES Consumer(ConsumerID)
        ,Rating INT CHECK (Rating >= 1 AND Rating <= 5)
        ,ReviewText VARCHAR(MAX)
        ,ReviewDate DATETIME
    )
END
ELSE
BEGIN
    PRINT 'Customer Reviews Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
                WHERE id = OBJECT_ID(N'[dbo].[LoyaltyProgram]')
                AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
    PRINT 'Loyalty Program Table Not Exists'
    CREATE TABLE LoyaltyProgram
    (
        LoyaltyProgramID BIGINT PRIMARY KEY IDENTITY(1,1)
        ,ConsumerID BIGINT FOREIGN KEY REFERENCES Consumer(ConsumerID)
        ,PointsEarned BIGINT DEFAULT 0
        ,PointsRedeemed BIGINT DEFAULT 0
        ,CurrentPointsBalance AS (PointsEarned - PointsRedeemed)
    )
END
ELSE
BEGIN
    PRINT 'Loyalty Program Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
                WHERE id = OBJECT_ID(N'[dbo].[EmployeeSchedule]')
                AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
    PRINT 'EmployeeSchedule Table Not Exists'
    CREATE TABLE EmployeeSchedule
    (
        ScheduleID BIGINT PRIMARY KEY IDENTITY(1,1)
        ,EmployeeID BIGINT FOREIGN KEY REFERENCES Employee(EmployeeID)
        ,WorkDate DATE
        ,StartTime TIME
        ,EndTime TIME
    )
END
ELSE
BEGIN
    PRINT 'EmployeeSchedule Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
                WHERE id = OBJECT_ID(N'[dbo].[OurServices]')
                AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
    PRINT 'OurServices Table Not Exists'
    CREATE TABLE OurServices
    (
        ServiceID BIGINT PRIMARY KEY IDENTITY(1,1)
		,StoreID BIGINT FOREIGN KEY REFERENCES Store(StoreID)
        ,ServiceName VARCHAR(30)
        ,StandardCharge DECIMAL(10, 2)
		
    )
END
ELSE
BEGIN
    PRINT 'OurServices Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
                WHERE id = OBJECT_ID(N'[dbo].[AppointmentStatus]')
                AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
    PRINT 'AppointmentStatus Table Not Exists'
    CREATE TABLE AppointmentStatus
    (
        StatusID INT PRIMARY KEY IDENTITY(1,1)
        ,StatusName VARCHAR(50)
    )
END
ELSE
BEGIN
    PRINT 'AppointmentStatus Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
                WHERE id = OBJECT_ID(N'[dbo].[ServiceAppointments]')
                AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
    PRINT 'ServiceAppointments Table Not Exists'
    CREATE TABLE ServiceAppointments
    (
        AppointmentID BIGINT PRIMARY KEY IDENTITY(1,1)
        ,ConsumerID BIGINT FOREIGN KEY REFERENCES Consumer(ConsumerID)
        ,ServiceID BIGINT FOREIGN KEY REFERENCES OurServices(ServiceID)
        ,StatusID INT FOREIGN KEY (StatusID) REFERENCES AppointmentStatus(StatusID)
		,AppointmentDate DATETIME
    )
END
ELSE
BEGIN
    PRINT 'ServiceAppointments Table Exists'
END


IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
                WHERE id = OBJECT_ID(N'[dbo].[Brand]')
                AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
    PRINT 'Brand Table Not Exists'
    CREATE TABLE Brand
    (
        BrandID INT PRIMARY KEY IDENTITY(1,1)
        ,BrandName VARCHAR(15)
    )
END
ELSE
BEGIN
    PRINT 'Brand Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
                WHERE id = OBJECT_ID(N'[dbo].[Shoes]')
                AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
    PRINT 'Shoes Table Not Exists'
    CREATE TABLE Shoes
    (
        ShoeID INT PRIMARY KEY IDENTITY(1,1)
        ,BrandID INT FOREIGN KEY REFERENCES Brand(BrandID)
		,ShoeType VARCHAR(20)
		,ShoeSize INT
    )
END
ELSE
BEGIN
    PRINT 'Shoes Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
                WHERE id = OBJECT_ID(N'[dbo].[SweatShirts]')
                AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
    PRINT 'SweatShirts Table Not Exists'
    CREATE TABLE SweatShirts
    (
        SweatShirtID INT PRIMARY KEY IDENTITY(1,1)
        ,BrandID INT FOREIGN KEY REFERENCES Brand(BrandID)
		,SweatShirtType VARCHAR(20)
		,SweatShirtSize INT
    )
END
ELSE
BEGIN
    PRINT 'SweatShirtd Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
                WHERE id = OBJECT_ID(N'[dbo].[TShirt]')
                AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
    PRINT 'TShirt Table Not Exists'
    CREATE TABLE TShirt
    (
        TShirtID INT PRIMARY KEY IDENTITY(1,1)
        ,BrandID INT FOREIGN KEY REFERENCES Brand(BrandID)
		,TShirtType VARCHAR(20)
		,TshirtSize INT
    )
END
ELSE
BEGIN
    PRINT 'TShirt Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
                WHERE id = OBJECT_ID(N'[dbo].[Shorts]')
                AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
    PRINT 'Shorts Table Not Exists'
    CREATE TABLE Shorts
    (
        ShortsID INT PRIMARY KEY IDENTITY(1,1)
        ,BrandID INT FOREIGN KEY REFERENCES Brand(BrandID)
		,ShortsType VARCHAR(20)
		,ShortsSize INT
    )
END
ELSE
BEGIN
    PRINT 'Shorts Table Exists'
END

IF NOT EXISTS (SELECT * FROM dbo.sysobjects 
                WHERE id = OBJECT_ID(N'[dbo].[Pants]')
                AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
    PRINT 'Pants Table Not Exists'
    CREATE TABLE Pants
    (
        PantsID INT PRIMARY KEY IDENTITY(1,1)
        ,BrandID INT FOREIGN KEY REFERENCES Brand(BrandID)
		,PantsType VARCHAR(20)
		,PantsSize INT
    )
END
ELSE
BEGIN
    PRINT 'Pants Table Exists'
END
