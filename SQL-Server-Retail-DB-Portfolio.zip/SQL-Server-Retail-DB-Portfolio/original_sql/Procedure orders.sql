IF EXISTS (SELECT * FROM sys.objects 
            WHERE object_id = OBJECT_ID(N'GroupingOrders') 
            AND type in (N'P', N'PC'))
DROP PROCEDURE GroupingOrders
GO


CREATE PROCEDURE GroupingOrders
	@ConsumerTypeName VARCHAR(20)
	,@ConsumerFirstName VARCHAR(20)
	,@ConsumerLastName VARCHAR(20)
	,@ProductName VARCHAR(20)
	,@Price INT
	,@ProducerFirstName VARCHAR(20)
	,@ProducerLastName VARCHAR(20)
	,@OrderTime DATETIME
	,@AddressType VARCHAR(25)
	,@Gift VARCHAR (3)
AS
BEGIN

	DECLARE @ProductID BIGINT
	DECLARE @ProducerID BIGINT
	DECLARE @ConsumerID BIGINT
	DECLARE @ConsumerTypeID BIGINT
	DECLARE @OrderID BIGINT
	DECLARE @AddressTypeID BIGINT
	DECLARE @GiftsID BIGINT


	IF NOT EXISTS (SELECT * FROM Producer WHERE FirtsName = @ProducerFirstName AND LastName = @ProducerLastName)
	BEGIN
		PRINT 'Producer Does Not Exist'
		INSERT INTO Producer (FirtsName, LastName)
		VALUES (@ProducerFirstName, @ProducerLastName)
	END
	SET @ProducerID = (SELECT ProducerID FROM Producer WHERE FirtsName = @ProducerFirstName AND LastName = @ProducerLastName)
	SET @ConsumerTypeID = (SELECT ConsumerTypeID FROM ConsumerType WHERE ConsumerType = @ConsumerTypeName)	
	SET @ProductID = (SELECT ProductID FROM Product WHERE ProductName = @ProductName AND ProducerID = @ProducerID)
	IF NOT EXISTS (SELECT * FROM Product WHERE ProductName = @ProductName AND ProducerID = @ProducerID)
	BEGIN
		PRINT 'Product Does Not Exist'
		INSERT INTO Product (ProducerID, ProductName, Price)
		VALUES(@ProducerID, @ProductName, @Price)
	END
		SET @ProductID = (SELECT ProductID FROM Product WHERE ProductName = @ProductName AND ProducerID = @ProducerID)

		SET @ConsumerTypeID = (SELECT ConsumerTypeID FROM ConsumerType WHERE ConsumerType = @ConsumerTypeName)
	END
	
	IF NOT EXISTS (SELECT * FROM Consumer WHERE ConsumerFirstName = @ConsumerFirstName AND ConsumerLastName = @ConsumerLastName AND ConsumerTypeID = @ConsumerTypeID)
	BEGIN
		PRINT 'Consumer Does Not Exist'
		INSERT INTO Consumer (ConsumerTypeID, ConsumerFirstName, ConsumerLastName)
		VALUES (@ConsumerTypeID, @ConsumerFirstName, @ConsumerLastName)
		SET @ConsumerID = (SELECT ConsumerID FROM Consumer WHERE ConsumerFirstName = @ConsumerFirstName AND ConsumerLastName = @ConsumerLastName AND ConsumerTypeID = @ConsumerTypeID)
	END
	 IF NOT EXISTS (SELECT * FROM ConsumerType WHERE ConsumerType = @ConsumerTypeName)
        BEGIN
            PRINT 'ConsumerType Does Not Exist'
            INSERT INTO ConsumerType(ConsumerType) 
			VALUES (@ConsumerTypeName)
        END

		 IF NOT EXISTS (SELECT * FROM AddressType WHERE AddressType = @AddressType)
        BEGIN
            PRINT 'Address Type Does Not Exist'
            INSERT INTO AddressType(AddressType) VALUES (@AddressType)
        END
        SET @AddressTypeID = (SELECT AddressTypeID FROM AddressType WHERE AddressType = @AddressType)

		IF NOT EXISTS (SELECT * FROM Gifts WHERE Gift = @Gift)
	BEGIN
		PRINT 'Gift Does Not Exist'
		INSERT INTO Gifts (Gift)
    VALUES (@Gift)
 END
	SET @GiftsID = (SELECT GiftsID FROM Gifts WHERE Gift = @Gift)

       IF NOT EXISTS (SELECT * FROM Orders WHERE OrderTime = @OrderTime)
        BEGIN
            PRINT 'Orders Does Not Exist'
            INSERT INTO Orders(ProductID, AddressTypeID, GiftsID, ConsumerID, OrderTime) 
			VALUES (@ProductID, @AddressTypeID, @GiftsID, @ConsumerID, @OrderTime)
	  END
	  SET @OrderID = SCOPE_IDENTITY()
	  GO


