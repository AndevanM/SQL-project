IF EXISTS (SELECT * FROM sys.objects 
            WHERE object_id = OBJECT_ID(N'StoreServices') 
            AND type in (N'P', N'PC'))
DROP PROCEDURE StoreServices
GO

CREATE PROCEDURE StoreServices
    @StateName VARCHAR(15) 
    ,@AddressType VARCHAR(20)
    ,@Street VARCHAR(30)
    ,@City VARCHAR(30)
    ,@Zip VARCHAR(11)
	,@StoreName VARCHAR(25)
	,@ServiceName VARCHAR(30)
	,@StandardCharge DECIMAL(10, 2)
AS
BEGIN
        DECLARE @StatesID BIGINT
        DECLARE @AddressTypeID BIGINT
        DECLARE @AddressesID BIGINT
		DECLARE @StoreID BIGINT
		DECLARE @ServiceID BIGINT


        IF NOT EXISTS (SELECT * FROM States WHERE StateName = @StateName)
        BEGIN
            PRINT 'State Name Does Not Exist';
            INSERT INTO States(StateName) VALUES (@StateName);
        END
        SET @StatesID = (SELECT StatesID FROM States WHERE StateName = @StateName);

        IF NOT EXISTS (SELECT * FROM AddressType WHERE AddressType = @AddressType)
        BEGIN
            PRINT 'Address Type Does Not Exist'
            INSERT INTO AddressType(AddressType) VALUES (@AddressType)
        END
        SET @AddressTypeID = (SELECT AddressTypeID FROM AddressType WHERE AddressType = @AddressType)

		IF NOT EXISTS (SELECT * FROM Addresses WHERE Street = @Street AND City = @City AND Zip = @Zip)
        BEGIN
            PRINT 'Address Does Not Exist'
            INSERT INTO Addresses (StatesID, AddressTypeID, Street, City, Zip)
            VALUES (@StatesID, @AddressTypeID, @Street, @City, @Zip)
        END
        SET @AddressesID = (SELECT AddressesID FROM Addresses WHERE Street = @Street AND City = @City AND Zip = @Zip)

		IF NOT EXISTS (SELECT * FROM Store WHERE StoreName = @StoreName)
        BEGIN
            PRINT 'Store Does Not Exist'
            INSERT INTO Store (AddressID, StoreName)
            VALUES (@AddressesID, @StoreName)
        END
        SET @StoreID = (SELECT StoreID FROM Store WHERE StoreName = @StoreName)
		
		IF NOT EXISTS (SELECT * FROM OurServices WHERE ServiceName = @ServiceName AND StandardCharge =@StandardCharge)
        BEGIN
            PRINT 'Store Does Not Exist'
            INSERT INTO OurServices (StoreID, ServiceName, StandardCharge)
            VALUES (@StoreID, @ServiceName, @StandardCharge)
        END
        SET @StoreID = (SELECT StoreID FROM Store WHERE StoreName = @StoreName)
	END