DECLARE @StateName VARCHAR(15) = 'New York'
,@AddressType VARCHAR(20) = 'Buisness'
,@Street VARCHAR(30) ='8 Wall St'
,@City VARCHAR(30) = 'New York'
,@Zip VARCHAR(11) = '10001'
,@StoreName VARCHAR(25) = 'FIDI'
,@ServiceName VARCHAR(30) ='Phonecase Design'
,@StandardCharge DECIMAL(10, 2) = 40.08

EXEC StoreServices
@StateName 
,@AddressType  
,@Street
,@City
,@Zip
,@StoreName
,@ServiceName
,@StandardCharge



SELECT Street, City, Zip, StateName, StoreName, ServiceName, StandardCharge
FROM Addresses a
INNER JOIN States s ON a.StatesID = s.StatesID
INNER JOIN Store st ON st.AddressID = A.AddressesID
INNER JOIN OurServices ou ON ou.StoreID = st.StoreID
Where StandardCharge < 150 ORDER BY StoreName DESC