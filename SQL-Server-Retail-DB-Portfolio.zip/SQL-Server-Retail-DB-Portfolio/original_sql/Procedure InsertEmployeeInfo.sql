IF EXISTS (SELECT * FROM sys.objects 
			WHERE object_id = OBJECT_ID(N'InsertEmployeeInfo') 
			AND type in (N'P', N'PC'))
DROP PROCEDURE InsertEmployeeInfo
GO


CREATE PROCEDURE InsertEmployeeInfo
    @EmployeeFirstName VARCHAR(20)
    ,@EmployeeLastName VARCHAR(20)
    ,@Salary INT
    ,@Email VARCHAR(30)
    ,@WorkDate DATE
    ,@StartTime TIME
    ,@EndTime TIME
    ,@EmployeeTypeName VARCHAR(20)
AS
BEGIN
    DECLARE @EmployeeID BIGINT
    DECLARE @EmployeeTypeID BIGINT
	DECLARE @ScheduleID BIGINT

    
    IF NOT EXISTS (SELECT * FROM EmployeeType WHERE EmployeeType = @EmployeeTypeName)
    BEGIN
        PRINT 'EmployeeType Does Not Exist'
        INSERT INTO EmployeeType (EmployeeType)
        VALUES (@EmployeeTypeName)
    END
    SET @EmployeeTypeID = (SELECT EmployeeTypeID FROM EmployeeType WHERE EmployeeType = @EmployeeTypeName)

    IF NOT EXISTS (SELECT * FROM Employee WHERE Email = @Email)
    BEGIN
        PRINT 'Employee Does Not Exist'
        INSERT INTO Employee (EmployeeTypeID, EmployeeFirstName, EmployeeLastName, Salary, Email)
        VALUES (@EmployeeTypeID, @EmployeeFirstName, @EmployeeLastName, @Salary, @Email)
        SET @EmployeeID = (SELECT EmployeeID FROM Employee Where Email = @Email) 
    END
    ELSE
    BEGIN
        SET @EmployeeID = (SELECT EmployeeID FROM Employee WHERE Email = @Email)
    END

    IF NOT EXISTS (SELECT * FROM EmployeeSchedule WHERE EmployeeID = @EmployeeID AND WorkDate = @WorkDate)
    BEGIN
        PRINT 'Employee Schedule Does Not Exist'
        INSERT INTO EmployeeSchedule(EmployeeID,WorkDate,StartTime,EndTime)
        VALUES (@EmployeeID, @WorkDate, @StartTime, @EndTime)
        SET @ScheduleID = (SELECT ScheduleID FROM EmployeeSchedule WHERE EmployeeID = @EmployeeID AND WorkDate = @WorkDate AND StartTime = @StartTime AND EndTime = @EndTime)
    END
END
