DECLARE @EmployeeFirstName VARCHAR(20) = 'Harry'
,@EmployeeLastName VARCHAR(20) = 'Styles'
,@Salary INT = 55000
,@Email VARCHAR(30) = 'HarrySyles@Store.com'
,@WorkDate DATE = '2023-12-11'
,@StartTime TIME = '18:07:20'
,@EndTime TIME = '23:55:50'
,@EmployeeTypeName VARCHAR(20) = 'Stocker'

EXEC InsertEmployeeInfo
@EmployeeFirstName
,@EmployeeLastName
,@Salary
,@Email
,@WorkDate
,@StartTime
,@EndTime
,@EmployeeTypeName 



SELECT et.EmployeeType, AVG(e.Salary) AS AverageSalary, COUNT(*) AS NumberOfJobs
FROM Employee e
JOIN EmployeeType et ON e.EmployeeTypeID = et.EmployeeTypeID
JOIN EmployeeSchedule es ON e.EmployeeID = es.EmployeeID 
WHERE es.WorkDate BETWEEN '2023-01-01' AND '2024-01-01'
GROUP BY et.EmployeeType
ORDER BY AverageSalary DESC

