DECLARE @ConsumerTypeName VARCHAR(20) = 'InFrequent'
	,@ConsumerFirstName VARCHAR (20) = 'Bob'
	,@ConsumerLastName VARCHAR (20) = 'Smith'
	,@ProductName VARCHAR (20) = 'Laptop'
	,@Price INT = 1100
	,@ProducerFirstName VARCHAR(20) = 'Apple'
	,@ProducerLastName VARCHAR(20) = 'Inc'
	,@OrderTime DATETIME = GETDATE()
	,@AddressType VARCHAR(25) = 'Residental'
	,@Gift VARCHAR (3) = 'No'

EXEC GroupingOrders 
	@ConsumerTypeName
	,@ConsumerFirstName 
	,@ConsumerLastName
	,@ProductName 
	,@Price 
	,@ProducerFirstName 
	,@ProducerLastName 
	,@OrderTime
	,@AddressType 
	,@Gift
	
	
	SELECT c.ConsumerFirstName, c.ConsumerLastName, ProductName, FirtsName AS CompamyFirstName, LastName AS CompanySecondName, Price, Gift, ConsumerType, OrderTime FROM Orders o
	INNER JOIN Consumer c ON c.ConsumerID = o.ConsumerID
	INNER JOIN ConsumerType ct ON ct.ConsumerTypeID = c.ConsumerTypeID
	INNER JOIN Product p ON p.ProductID = o.ProductID
	INNER JOIN Producer pr ON pr.ProducerID = p.ProducerID
	INNER JOIN Gifts g ON g.GiftsID = o.GiftsID
	WHERE Price > 1000  ORDER BY ConsumerLastName 