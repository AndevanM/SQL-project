/*
Run order (SQL Server)
1) Schema
2) Stored procedures
3) Optional seed data
*/

:r .\01_schema.sql
:r .\02_procedures\usp_InsertEmployeeInfo.sql
:r .\02_procedures\usp_StoreServices.sql
:r .\02_procedures\usp_GroupingOrders.sql
:r .\00_seed_demo_data.sql

-- Optional: example queries
-- :r .\03_queries\orders_joins.sql
-- :r .\03_queries\store_services_joins.sql
-- :r .\03_queries\employee_schedule_joins.sql
