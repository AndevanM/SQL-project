/*
Optional demo seed data
- Adds a few lookup values so procedures can be tested quickly.
- Safe to re-run (uses IF NOT EXISTS).
*/

-- States
IF NOT EXISTS (SELECT 1 FROM dbo.States WHERE StateName = 'FL') INSERT INTO dbo.States(StateName) VALUES ('FL');
IF NOT EXISTS (SELECT 1 FROM dbo.States WHERE StateName = 'NY') INSERT INTO dbo.States(StateName) VALUES ('NY');

-- Address Types
IF NOT EXISTS (SELECT 1 FROM dbo.AddressType WHERE AddressType = 'Home') INSERT INTO dbo.AddressType(AddressType) VALUES ('Home');
IF NOT EXISTS (SELECT 1 FROM dbo.AddressType WHERE AddressType = 'Store') INSERT INTO dbo.AddressType(AddressType) VALUES ('Store');

-- Payment Types
IF NOT EXISTS (SELECT 1 FROM dbo.Payment WHERE PaymentType = 'Credit') INSERT INTO dbo.Payment(PaymentType) VALUES ('Credit');
IF NOT EXISTS (SELECT 1 FROM dbo.Payment WHERE PaymentType = 'Cash') INSERT INTO dbo.Payment(PaymentType) VALUES ('Cash');

-- Consumer Types
IF NOT EXISTS (SELECT 1 FROM dbo.ConsumerType WHERE ConsumerType = 'Retail') INSERT INTO dbo.ConsumerType(ConsumerType) VALUES ('Retail');
IF NOT EXISTS (SELECT 1 FROM dbo.ConsumerType WHERE ConsumerType = 'Business') INSERT INTO dbo.ConsumerType(ConsumerType) VALUES ('Business');

-- Appointment Status
IF NOT EXISTS (SELECT 1 FROM dbo.AppointmentStatus WHERE StatusName = 'Scheduled') INSERT INTO dbo.AppointmentStatus(StatusName) VALUES ('Scheduled');
IF NOT EXISTS (SELECT 1 FROM dbo.AppointmentStatus WHERE StatusName = 'Completed') INSERT INTO dbo.AppointmentStatus(StatusName) VALUES ('Completed');
IF NOT EXISTS (SELECT 1 FROM dbo.AppointmentStatus WHERE StatusName = 'Cancelled') INSERT INTO dbo.AppointmentStatus(StatusName) VALUES ('Cancelled');
