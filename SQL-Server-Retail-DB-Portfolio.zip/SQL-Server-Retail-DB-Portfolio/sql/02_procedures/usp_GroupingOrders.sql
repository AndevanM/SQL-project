/*
usp_GroupingOrders
- Demonstrates an "upsert-style" stored procedure for orders.
- Inserts missing lookup/parent records (Producer, Product, ConsumerType, Consumer, AddressType, Gifts)
  and then inserts a row into Orders.

Notes:
- The original course version had a GO inside the procedure body and a few ordering issues.
- This refactored version keeps the intent but compiles cleanly in SQL Server.
*/

IF OBJECT_ID(N'dbo.usp_GroupingOrders', N'P') IS NOT NULL
    DROP PROCEDURE dbo.usp_GroupingOrders;
GO

CREATE PROCEDURE dbo.usp_GroupingOrders
    @ConsumerTypeName     VARCHAR(20),
    @ConsumerFirstName    VARCHAR(20),
    @ConsumerLastName     VARCHAR(20),
    @ProductName          VARCHAR(20),
    @Price                INT,
    @ProducerFirstName    VARCHAR(20),
    @ProducerLastName     VARCHAR(20),
    @OrderTime            DATETIME,
    @AddressType          VARCHAR(25),
    @Gift                 VARCHAR(3)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ProductID       BIGINT;
    DECLARE @ProducerID      BIGINT;
    DECLARE @ConsumerID      BIGINT;
    DECLARE @ConsumerTypeID  BIGINT;
    DECLARE @AddressTypeID   BIGINT;
    DECLARE @GiftsID         INT;

    -- ConsumerType
    IF NOT EXISTS (SELECT 1 FROM dbo.ConsumerType WHERE ConsumerType = @ConsumerTypeName)
    BEGIN
        INSERT INTO dbo.ConsumerType(ConsumerType) VALUES (@ConsumerTypeName);
    END
    SELECT @ConsumerTypeID = ConsumerTypeID
    FROM dbo.ConsumerType
    WHERE ConsumerType = @ConsumerTypeName;

    -- Producer
    IF NOT EXISTS (SELECT 1 FROM dbo.Producer WHERE FirtsName = @ProducerFirstName AND LastName = @ProducerLastName)
    BEGIN
        INSERT INTO dbo.Producer(FirtsName, LastName) VALUES (@ProducerFirstName, @ProducerLastName);
    END
    SELECT @ProducerID = ProducerID
    FROM dbo.Producer
    WHERE FirtsName = @ProducerFirstName AND LastName = @ProducerLastName;

    -- Product
    IF NOT EXISTS (SELECT 1 FROM dbo.Product WHERE ProductName = @ProductName AND ProducerID = @ProducerID)
    BEGIN
        INSERT INTO dbo.Product(ProducerID, ProductName, Price)
        VALUES (@ProducerID, @ProductName, @Price);
    END
    SELECT @ProductID = ProductID
    FROM dbo.Product
    WHERE ProductName = @ProductName AND ProducerID = @ProducerID;

    -- Consumer
    IF NOT EXISTS (
        SELECT 1
        FROM dbo.Consumer
        WHERE ConsumerFirstName = @ConsumerFirstName
          AND ConsumerLastName  = @ConsumerLastName
          AND ConsumerTypeID    = @ConsumerTypeID
    )
    BEGIN
        INSERT INTO dbo.Consumer(ConsumerTypeID, ConsumerFirstName, ConsumerLastName)
        VALUES (@ConsumerTypeID, @ConsumerFirstName, @ConsumerLastName);
    END
    SELECT @ConsumerID = ConsumerID
    FROM dbo.Consumer
    WHERE ConsumerFirstName = @ConsumerFirstName
      AND ConsumerLastName  = @ConsumerLastName
      AND ConsumerTypeID    = @ConsumerTypeID;

    -- AddressType
    IF NOT EXISTS (SELECT 1 FROM dbo.AddressType WHERE AddressType = @AddressType)
    BEGIN
        INSERT INTO dbo.AddressType(AddressType) VALUES (@AddressType);
    END
    SELECT @AddressTypeID = AddressTypeID
    FROM dbo.AddressType
    WHERE AddressType = @AddressType;

    -- Gifts
    IF NOT EXISTS (SELECT 1 FROM dbo.Gifts WHERE Gift = @Gift)
    BEGIN
        INSERT INTO dbo.Gifts(Gift) VALUES (@Gift);
    END
    SELECT @GiftsID = GiftsID
    FROM dbo.Gifts
    WHERE Gift = @Gift;

    -- Orders
    INSERT INTO dbo.Orders(ProductID, AddressTypeID, GiftsID, ConsumerID, OrderTime)
    VALUES (@ProductID, @AddressTypeID, @GiftsID, @ConsumerID, @OrderTime);

    SELECT SCOPE_IDENTITY() AS OrdersID;
END
GO
