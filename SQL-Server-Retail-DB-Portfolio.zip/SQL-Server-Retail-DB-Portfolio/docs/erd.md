# ER Diagram (Mermaid)

Paste this into any Markdown viewer that supports Mermaid (including GitHub).

```mermaid
erDiagram
  STATES ||--o{ ADDRESSES : has
  ADDRESSTYPE ||--o{ ADDRESSES : categorizes

  PRODUCER ||--o{ PRODUCT : makes
  PRODUCT ||--o{ ORDERS : ordered
  CONSUMERTYPE ||--o{ CONSUMER : classifies
  CONSUMER ||--o{ ORDERS : places
  GIFTS ||--o{ ORDERS : includes
  ADDRESSTYPE ||--o{ ORDERS : ships_to_type

  ADDRESSES ||--o{ STORE : located_at
  STORE ||--o{ INVENTORY : stocks
  PRODUCT ||--o{ INVENTORY : stocked_item

  STORE ||--o{ OURSERVICES : offers
  CONSUMER ||--o{ SERVICEAPPOINTMENTS : books
  OURSERVICES ||--o{ SERVICEAPPOINTMENTS : scheduled_for
  APPOINTMENTSTATUS ||--o{ SERVICEAPPOINTMENTS : status

  EMPLOYEETYPE ||--o{ EMPLOYEE : categorizes
  EMPLOYEE ||--o{ EMPLOYEESCHEDULE : has

  PAYMENT ||--o{ SALESRECORD : paid_with
  STORE ||--o{ SALESRECORD : sold_at
  PRODUCT ||--o{ SALESRECORD : sold_item
  CONSUMER ||--o{ SALESRECORD : bought_by
```
