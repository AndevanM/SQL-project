# SQL Server Retail Database (Portfolio)

A SQL Server database project that models a **retail + services business**: products, producers, consumers, orders, stores, inventory, employee schedules, and service appointments.

This repo is organized as a **portfolio-ready SQL project** with a clear run order, stored procedures, and example join queries.

## What’s inside

### Core features
- **Relational schema** with FK constraints (stores, inventory, orders, shipping, employees, services)
- **Stored procedures** for common workflows:
  - `dbo.usp_InsertEmployeeInfo` → inserts employee + employee type + schedule
  - `dbo.usp_StoreServices` → inserts store address + store + services
  - `dbo.usp_GroupingOrders` → upsert-style order workflow (producer/product/consumer + order)
- **Join/query scripts** (examples of reporting-style SQL)
- Optional demo seed data for quick testing

### Tech
- **Microsoft SQL Server** (T-SQL)
- Designed to run in **SSMS** (SQL Server Management Studio)

## Repo structure
```
SQL-Server-Retail-DB-Portfolio/
  sql/
    00_seed_demo_data.sql
    01_schema.sql
    run_all.sql
    02_procedures/
      usp_InsertEmployeeInfo.sql
      usp_StoreServices.sql
      usp_GroupingOrders.sql
    03_queries/
      orders_joins.sql
      store_services_joins.sql
      employee_schedule_joins.sql
  docs/
    erd.md
  original_sql/
    (original course submission scripts)
```

## How to run

### Option A (recommended): run the full build script
1. Open **SSMS** → connect to your SQL Server instance.
2. Create or select a database (example: `RetailPortfolioDB`).
3. Open `sql/run_all.sql` and execute.

> Note: `run_all.sql` uses SQLCMD `:r` commands. In SSMS, enable it: **Query → SQLCMD Mode**.

### Option B: run manually
Run these in order:
1. `sql/01_schema.sql`
2. `sql/02_procedures/*.sql`
3. (Optional) `sql/00_seed_demo_data.sql`
4. (Optional) `sql/03_queries/*.sql`

## Quick demo (examples)

### Insert an employee + schedule
```sql
EXEC dbo.InsertEmployeeInfo
  @EmployeeFirstName = 'Ava',
  @EmployeeLastName  = 'Martinez',
  @Salary            = 52000,
  @Email             = 'ava.martinez@example.com',
  @WorkDate          = '2026-03-03',
  @StartTime         = '09:00',
  @EndTime           = '17:00',
  @EmployeeTypeName  = 'Cashier';
```

### Create a store + service offering
```sql
EXEC dbo.StoreServices
  @StateName       = 'FL',
  @AddressType     = 'Store',
  @Street          = '100 Market St',
  @City            = 'Orlando',
  @Zip             = '32801',
  @StoreName       = 'Downtown Orlando Store',
  @ServiceName     = 'Device Setup',
  @StandardCharge  = 49.99;
```

### Create an order (upsert-style)
```sql
EXEC dbo.usp_GroupingOrders
  @ConsumerTypeName   = 'Retail',
  @ConsumerFirstName  = 'Evan',
  @ConsumerLastName   = 'Anderson',
  @ProductName        = 'Headphones',
  @Price              = 79,
  @ProducerFirstName  = 'Acme',
  @ProducerLastName   = 'Audio',
  @OrderTime          = GETDATE(),
  @AddressType        = 'Home',
  @Gift               = 'Yes';
```

## ER Diagram
See `docs/erd.md` for a Mermaid ERD you can render directly on GitHub.

## Notes (portfolio transparency)
- The `original_sql/` folder keeps the **original assignment scripts**.
- The `sql/` folder contains a **portfolio-friendly** layout (run order + cleaned procedure names + a compile-safe order procedure).

## Author
Evan Anderson
